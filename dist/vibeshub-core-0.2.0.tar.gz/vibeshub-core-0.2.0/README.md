# VibesHub Core

**Simple utilities for Python developers.**

## Installation

```bash
pip install vibeshub-core
